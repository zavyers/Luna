/* Luna UI logic. Talks only to the local Luna server (same origin). All text from the
   user or the AI is inserted with textContent, never as HTML. */
(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const TOKEN = $('meta[name="luna-token"]').content;
  const SVG_NS = 'http://www.w3.org/2000/svg';

  // ---------------------------------------------------------------- helpers

  async function api(method, args = {}) {
    let res;
    try {
      res = await fetch('/api/' + method, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Luna-Token': TOKEN },
        body: JSON.stringify(args),
      });
    } catch (_) {
      throw new Error("Luna's engine isn't responding. Close Luna and start her again.");
    }
    let data = {};
    try { data = await res.json(); } catch (_) { /* keep empty */ }
    if (!res.ok) throw new Error(data.error || 'That request failed.');
    return data;
  }

  function el(tag, props = {}, ...kids) {
    const node = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) {
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k.startsWith('on')) node.addEventListener(k.slice(2), v);
      else if (v === true) node.setAttribute(k, '');
      else if (v !== false && v != null) node.setAttribute(k, v);
    }
    kids.forEach((kid) => kid != null && node.append(kid));
    return node;
  }

  function icon(d) {
    const svg = document.createElementNS(SVG_NS, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    for (const part of d.split('|')) {
      const path = document.createElementNS(SVG_NS, 'path');
      path.setAttribute('d', part);
      svg.append(path);
    }
    return svg;
  }
  const ICON = {
    chev: 'M9 6l6 6-6 6',
    folder: 'M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z',
    chat: 'M5 5h14a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-7l-5 4v-4H5a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z',
    plus: 'M12 5v14|M5 12h14',
    edit: 'M4 20h4L19 9l-4-4L4 16z',
    trash: 'M5 7h14|M10 7V4h4v3|M7 7l1 13h8l1-13',
  };

  function store(key, value) {
    try {
      if (value === undefined) return JSON.parse(localStorage.getItem(key) || 'null');
      localStorage.setItem(key, JSON.stringify(value));
    } catch (_) { /* storage can be unavailable; the UI works without it */ }
    return null;
  }

  // ------------------------------------------------------------------ state

  const S = {
    chatId: null,
    chat: null,
    state: 'IDLE',
    busy: false,
    gemini: 'unknown',
    setup: '',
    overview: { projects: [], chats: [] },
    query: '',
    closed: new Set(store('luna.closedProjects') || []), // projects start expanded so every chat is visible
  };

  const els = {
    stateLabel: $('#stateLabel'), stateLine: $('#stateLine'), core: $('#coreSvg'),
    convo: $('#convo'), convoTitle: $('#convoTitle'),
    input: $('#input'), form: $('#form'), stop: $('#stopBtn'), mic: $('#micBtn'),
    chipGemini: $('#chipGemini'), subtitle: $('#subtitle'),
    drawer: $('#drawer'), scrim: $('#scrim'), menuBtn: $('#menuBtn'), list: $('#drawerList'),
    search: $('#search'), toast: $('#toast'),
  };

  // ------------------------------------------------------------------ states

  function greeting() {
    const h = new Date().getHours();
    const part = h < 5 ? 'Good evening' : h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
    return `${part}. How can I help?`;
  }

  let errorTimer = null;
  function setState(name, line) {
    S.state = name;
    document.body.dataset.state = name;
    els.stateLabel.textContent = name;
    els.stateLine.textContent = line || greeting();
    els.core.setAttribute('aria-label', 'Luna core, state: ' + name.toLowerCase());
    els.stop.hidden = name !== 'SPEAKING';
    wave.restart();
    clearTimeout(errorTimer);
    if (name === 'ERROR') {
      errorTimer = setTimeout(() => { if (S.state === 'ERROR') setState('IDLE'); }, 9000);
    }
  }

  function applyStatus(st) {
    S.gemini = st.gemini;
    S.setup = st.setup_message || '';
    const chip = els.chipGemini;
    const map = {
      missing_key: ['KEY MISSING', 'bad', 'SETUP NEEDED'],
      configured: ['KEY SET', 'warn', 'KEY SET'],
      ready: ['READY', 'ok', 'ONLINE'],
      error: ['ERROR', 'bad', 'OFFLINE'],
    };
    const [label, tone, sub] = map[st.gemini] || ['…', 'warn', 'STARTING'];
    chip.textContent = label;
    chip.dataset.tone = tone;
    els.subtitle.textContent = 'AI ASSISTANT · ' + sub;
  }

  // ------------------------------------------------------------------ waveform

  const wave = (() => {
    const canvas = $('#wave');
    const ctx = canvas.getContext('2d');
    const BARS = 72;
    let w = 0, h = 0, raf = 0, last = 0, ext = 0, extAt = 0;
    const css = (name) => getComputedStyle(document.body).getPropertyValue(name).trim() || '#35c9ea';

    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      const r = canvas.getBoundingClientRect();
      w = Math.max(1, Math.round(r.width * dpr));
      h = Math.max(1, Math.round(r.height * dpr));
      canvas.width = w; canvas.height = h;
      draw(performance.now());
    }

    function amplitude(i, t) {
      const x = i / (BARS - 1);
      const envelope = Math.sin(Math.PI * x) ** 1.2; // taller in the middle
      switch (S.state) {
        case 'LISTENING':
        case 'SPEAKING': {
          const live = performance.now() - extAt < 400 ? ext : null; // real mic/speaker level when provided
          const base = live !== null ? 0.25 + 0.75 * live : 0.55;
          const n = Math.sin(t * 0.009 + i * 0.7) * Math.sin(t * 0.0053 + i * 1.9);
          return envelope * base * (0.35 + 0.65 * Math.abs(n)) + 0.04;
        }
        case 'THINKING': {
          const pos = (t * 0.0007) % 1.4 - 0.2;
          const d = Math.abs(x - pos);
          return Math.max(0.04, Math.exp(-d * d * 90) * 0.9);
        }
        default:
          return 0.0;
      }
    }

    function draw(t) {
      ctx.clearRect(0, 0, w, h);
      const accent = css('--accent');
      const violet = css('--violet');
      const step = w / BARS;
      const bw = Math.max(1.5, step * 0.38);
      ctx.fillStyle = accent;
      for (let i = 0; i < BARS; i++) {
        const a = amplitude(i, t);
        const bh = Math.max(bw, a * h);
        ctx.fillStyle = a > 0.3 && i % 6 === 3 ? violet : accent;
        ctx.globalAlpha = a > 0 ? 0.55 + 0.45 * Math.min(1, a * 1.5) : 0.55;
        ctx.fillRect(i * step + (step - bw) / 2, (h - bh) / 2, bw, bh);
      }
      ctx.globalAlpha = 1;
    }

    function loop(t) {
      raf = 0;
      if (document.hidden) return;
      if (t - last >= 33) { last = t; draw(t); } // ~30 fps keeps old laptops cool
      if (S.state === 'LISTENING' || S.state === 'SPEAKING' || S.state === 'THINKING') raf = requestAnimationFrame(loop);
    }

    function restart() {
      cancelAnimationFrame(raf);
      raf = 0;
      draw(performance.now());
      if (S.state === 'LISTENING' || S.state === 'SPEAKING' || S.state === 'THINKING') raf = requestAnimationFrame(loop);
    }

    new ResizeObserver(resize).observe(canvas);
    return { restart, resize, setLevel(v) { ext = Math.max(0, Math.min(1, v)); extAt = performance.now(); } };
  })();

  // ------------------------------------------------------------------ toast + modal

  let toastTimer = null;
  function toast(text) {
    els.toast.textContent = text;
    els.toast.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { els.toast.hidden = true; }, 3800);
  }

  const modal = { root: $('#modal'), title: $('#modalTitle span'), body: $('#modalBody'), actions: $('#modalActions'), restore: null, onEsc: null };

  function openModal(title, bodyNode, buttons, onEsc) {
    modal.title.textContent = title;
    modal.body.replaceChildren(bodyNode);
    modal.actions.replaceChildren(...buttons);
    modal.restore = document.activeElement;
    modal.onEsc = onEsc || closeModal;
    modal.root.hidden = false;
    const first = modal.body.querySelector('input') || modal.actions.querySelector('button:last-child');
    if (first) first.focus();
  }
  function closeModal() {
    modal.root.hidden = true;
    modal.onEsc = null;
    if (modal.restore && modal.restore.focus) modal.restore.focus();
  }

  function confirmDialog(title, message, confirmLabel) {
    return new Promise((resolve) => {
      const done = (v) => { closeModal(); resolve(v); };
      openModal(title, el('p', { text: message }), [
        el('button', { class: 'btn', text: 'CANCEL', onclick: () => done(false) }),
        el('button', { class: 'btn danger', text: confirmLabel, onclick: () => done(true) }),
      ], () => done(false));
    });
  }

  function promptDialog(title, label, initial, okLabel) {
    return new Promise((resolve) => {
      const input = el('input', { class: 'modal-input', type: 'text', maxlength: '60', value: initial || '', 'aria-label': label, placeholder: label });
      const done = (v) => { closeModal(); resolve(v); };
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); done(input.value); } });
      openModal(title, input, [
        el('button', { class: 'btn', text: 'CANCEL', onclick: () => done(null) }),
        el('button', { class: 'btn primary', text: okLabel || 'OK', onclick: () => done(input.value) }),
      ], () => done(null));
      input.select();
    });
  }

  async function settingsDialog() {
    let st;
    try { st = await api('status'); } catch (e) { toast(e.message); return; }
    const labels = { missing_key: 'Key missing', configured: 'Key set (not tested)', ready: 'Connected', error: 'Error' };
    const statusDd = el('dd', { text: labels[st.gemini] || st.gemini });
    const result = el('p', { class: 'result', hidden: true });
    const dl = el('dl', {},
      el('dt', { text: 'GEMINI' }), statusDd,
      el('dt', { text: 'MODEL' }), el('dd', { text: st.model }),
      el('dt', { text: 'KEY FILE' }), el('dd', { text: st.env_file }));
    const note = el('p', { class: 'note', text: 'Your Gemini key lives only in the .env file. Luna never shows it here, never logs it and never sends it anywhere except to Google Gemini.' });
    const testBtn = el('button', { class: 'btn primary', text: 'TEST CONNECTION' });
    testBtn.addEventListener('click', async () => {
      testBtn.disabled = true;
      testBtn.textContent = 'TESTING…';
      try {
        const r = await api('test_connection');
        applyStatus(r);
        statusDd.textContent = labels[r.gemini] || r.gemini;
        result.hidden = false;
        result.className = 'result ' + (r.gemini === 'ready' ? 'ok' : 'bad');
        result.textContent = r.gemini === 'ready' ? 'Gemini answered. Luna is ready.'
          : r.gemini === 'missing_key' ? 'No key found. Add it to the .env file and restart Luna.'
          : (r.gemini_detail || 'Gemini did not answer.');
      } catch (e) {
        result.hidden = false; result.className = 'result bad'; result.textContent = e.message;
      }
      testBtn.disabled = false;
      testBtn.textContent = 'TEST CONNECTION';
      refreshActivity();
    });
    openModal('SETTINGS', el('div', {}, dl, result, note), [
      testBtn,
      el('button', { class: 'btn', text: 'CLOSE', onclick: closeModal }),
    ]);
  }

  // ------------------------------------------------------------------ conversation view

  function scrollDown() { els.convo.scrollTop = els.convo.scrollHeight; }

  function addMsg(role, text, who) {
    const node = el('div', { class: 'msg ' + role }, el('span', { class: 'who', text: who || (role === 'you' ? 'YOU' : 'LUNA') }), document.createTextNode(text));
    els.convo.append(node);
    scrollDown();
    return node;
  }

  function addTyping() {
    const node = el('div', { class: 'msg luna', 'aria-label': 'Luna is thinking' }, el('span', { class: 'who', text: 'LUNA' }),
      el('span', { class: 'dots' }, el('span'), el('span'), el('span')));
    els.convo.append(node);
    scrollDown();
    return node;
  }

  function showWelcome() {
    els.convo.replaceChildren();
    if (S.gemini === 'missing_key') {
      addMsg('err', S.setup, 'SETUP NEEDED');
    } else {
      els.convo.append(el('p', { class: 'welcome', text: 'Type a message, or say “new chat” or “new project” to start fresh. Open the menu to see all your chats.' }));
    }
  }

  function renderChat(chat) {
    S.chatId = chat.id;
    S.chat = chat;
    const title = chat.project ? `${chat.project.name} / ${chat.title}` : chat.title;
    els.convoTitle.textContent = title.toUpperCase();
    els.convoTitle.title = title;
    els.convo.replaceChildren();
    if (!chat.messages.length) showWelcome();
    else chat.messages.forEach((m) => addMsg(m.role === 'user' ? 'you' : 'luna', m.text));
    scrollDown();
    highlightActive();
  }

  function firstSentence(text, max = 90) {
    const flat = text.replace(/\s+/g, ' ').trim();
    const cut = flat.search(/[.!?](\s|$)/);
    const s = cut > 12 ? flat.slice(0, cut + 1) : flat;
    return s.length > max ? s.slice(0, max - 1).trimEnd() + '…' : s;
  }

  async function send(text) {
    text = text.trim();
    if (!text || S.busy) return;
    S.busy = true;
    els.form.classList.add('busy');
    const sentTo = S.chatId;
    els.convo.querySelector('.welcome')?.remove();
    if (S.gemini === 'missing_key') els.convo.querySelector('.msg.err')?.remove();
    const mine = addMsg('you', text);
    const typing = addTyping();
    els.input.value = '';
    setState('THINKING', 'Thinking…');

    let r = null;
    try {
      r = await api('send', { chat_id: sentTo, text });
    } catch (e) {
      r = { ok: false, text: e.message, error_kind: 'ai', restore_text: text };
    }
    typing.remove();

    if (!r.ok) {
      mine.remove();
      els.input.value = r.restore_text || text;
      const missing = r.error_kind === 'missing_key';
      if (missing) applyStatus({ gemini: 'missing_key', setup_message: r.text });
      else if (S.gemini !== 'missing_key') applyStatus({ gemini: 'error', setup_message: S.setup });
      if (S.chatId === sentTo || !sentTo) addMsg('err', r.text, missing ? 'SETUP NEEDED' : 'ERROR');
      setState('ERROR', missing ? 'Gemini key needed' : firstSentence(r.text));
    } else if (r.action) {
      renderChat(r.chat);
      toast(r.text);
      setState('IDLE');
    } else {
      applyStatus({ gemini: 'ready', setup_message: '' });
      if (r.chat && (S.chatId === sentTo || !sentTo)) {
        S.chatId = r.chat.id;
        addMsg('luna', r.text);
        els.convoTitle.textContent = (r.chat.project ? `${r.chat.project.name} / ${r.chat.title}` : r.chat.title).toUpperCase();
      } else if (r.chat) {
        toast(`Luna replied in “${r.chat.title}”.`);
      }
      setState('IDLE');
    }

    S.busy = false;
    els.form.classList.remove('busy');
    els.input.focus();
    refreshMenu();
    refreshActivity();
  }

  // ------------------------------------------------------------------ menu drawer

  function openDrawer() {
    els.drawer.classList.add('open');
    els.drawer.removeAttribute('inert');
    els.drawer.setAttribute('aria-hidden', 'false');
    els.scrim.hidden = false;
    els.menuBtn.setAttribute('aria-expanded', 'true');
    refreshMenu();
    $('#newChatBtn').focus();
  }
  function closeDrawer() {
    if (!els.drawer.classList.contains('open')) return;
    els.drawer.classList.remove('open');
    els.drawer.setAttribute('inert', '');
    els.drawer.setAttribute('aria-hidden', 'true');
    els.scrim.hidden = true;
    els.menuBtn.setAttribute('aria-expanded', 'false');
    els.menuBtn.focus();
  }
  const toggleDrawer = () => (els.drawer.classList.contains('open') ? closeDrawer() : openDrawer());

  async function refreshMenu() {
    try { S.overview = await api('overview', { query: S.query, keep_id: S.chatId || '' }); } catch (_) { return; }
    renderMenu();
  }

  function highlightActive() {
    els.list.querySelectorAll('.row[data-chat]').forEach((row) => row.classList.toggle('active', row.dataset.chat === S.chatId));
  }

  function actBtn(label, path, cls, handler) {
    const b = el('button', { class: 'row-act ' + (cls || ''), 'aria-label': label, title: label, type: 'button' }, icon(path));
    b.addEventListener('click', (e) => { e.stopPropagation(); handler(); });
    return b;
  }

  function chatRow(c) {
    const main = el('button', { class: 'row-main', type: 'button', title: c.title },
      icon(ICON.chat), el('span', { class: 't', text: c.title }), el('span', { class: 'n', text: c.count ? String(c.count) : '' }));
    main.addEventListener('click', () => openChat(c.id));
    const row = el('div', { class: 'row', 'data-chat': c.id }, main,
      el('div', { class: 'row-acts' },
        actBtn('Rename chat', ICON.edit, '', () => inlineRename(row, main, c.title, (v) => api('rename_chat', { chat_id: c.id, title: v }))),
        actBtn('Delete chat', ICON.trash, 'del', () => deleteChat(c))));
    if (c.id === S.chatId) row.classList.add('active');
    return row;
  }

  function projectRow(p) {
    const open = !S.closed.has(p.id) || (S.query && p.chats.length > 0);
    const chev = icon(ICON.chev);
    chev.classList.add('chev');
    const main = el('button', { class: 'row-main', type: 'button', 'aria-expanded': String(open) },
      chev, icon(ICON.folder), el('span', { class: 't', text: p.name }), el('span', { class: 'n', text: String(p.chats.length) }));
    const wrap = el('div', { class: 'proj' + (open ? ' open' : '') });
    main.addEventListener('click', () => {
      wrap.classList.toggle('open');
      const isOpen = wrap.classList.contains('open');
      main.setAttribute('aria-expanded', String(isOpen));
      isOpen ? S.closed.delete(p.id) : S.closed.add(p.id);
      store('luna.closedProjects', [...S.closed]);
    });
    const head = el('div', { class: 'row' }, main,
      el('div', { class: 'row-acts' },
        actBtn('New chat in this project', ICON.plus, '', async () => {
          try { renderChat(await api('new_chat', { project_id: p.id })); } catch (e) { toast(e.message); return; }
          S.closed.delete(p.id); store('luna.closedProjects', [...S.closed]);
          setState('IDLE'); await refreshMenu(); closeDrawer(); els.input.focus();
        }),
        actBtn('Rename project', ICON.edit, '', () => inlineRename(head, main, p.name, (v) => api('rename_project', { project_id: p.id, name: v }))),
        actBtn('Delete project', ICON.trash, 'del', () => deleteProject(p))));
    const body = el('div', { class: 'proj-body' }, ...p.chats.map(chatRow));
    if (!p.chats.length) body.append(el('p', { class: 'none-yet', text: 'No chats yet' }));
    wrap.append(head, body);
    return wrap;
  }

  function renderMenu() {
    const { projects, chats } = S.overview;
    const nodes = [];
    nodes.push(el('div', { class: 'sec' }, el('span', { text: 'PROJECTS' }), el('span', { text: String(projects.length) })));
    if (!projects.length) nodes.push(el('p', { class: 'none-yet', text: S.query ? 'No matches' : 'No projects yet' }));
    projects.forEach((p) => nodes.push(projectRow(p)));
    nodes.push(el('div', { class: 'sec' }, el('span', { text: 'CHATS' }), el('span', { text: String(chats.length) })));
    if (!chats.length) nodes.push(el('p', { class: 'none-yet', text: S.query ? 'No matches' : 'No chats yet' }));
    chats.forEach((c) => nodes.push(chatRow(c)));
    els.list.replaceChildren(...nodes);
  }

  function inlineRename(row, main, current, commit) {
    const input = el('input', { class: 'row-edit', type: 'text', maxlength: '60', value: current, 'aria-label': 'New name' });
    let finished = false;
    const finish = async (save) => {
      if (finished) return;
      finished = true;
      const value = input.value.trim();
      if (save && value && value !== current) {
        try { await commit(value); } catch (e) { toast(e.message); }
      }
      await refreshMenu();
      if (S.chatId) { try { renderChat(await api('open_chat', { chat_id: S.chatId })); } catch (_) { /* chat may be gone */ } }
    };
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      if (e.key === 'Escape') { e.stopPropagation(); finish(false); }
    });
    input.addEventListener('blur', () => finish(true));
    main.replaceWith(input);
    input.focus();
    input.select();
  }

  async function openChat(id) {
    try { renderChat(await api('open_chat', { chat_id: id })); } catch (e) { toast(e.message); refreshMenu(); return; }
    setState('IDLE');
    closeDrawer();
    els.input.focus();
  }

  async function reopenAfterDelete() {
    try { renderChat(await api('start')); } catch (e) { toast(e.message); }
    await refreshMenu();
  }

  async function deleteChat(c) {
    const ok = await confirmDialog('DELETE CHAT', `Delete “${c.title}”? This can't be undone.`, 'DELETE');
    if (!ok) return;
    try { await api('delete_chat', { chat_id: c.id }); } catch (e) { toast(e.message); return; }
    toast('Chat deleted.');
    if (c.id === S.chatId) await reopenAfterDelete(); else await refreshMenu();
  }

  async function deleteProject(p) {
    const n = p.chats.length;
    const msg = n ? `Delete the project “${p.name}” and its ${n} chat${n === 1 ? '' : 's'}? This can't be undone.` : `Delete the empty project “${p.name}”?`;
    const ok = await confirmDialog('DELETE PROJECT', msg, 'DELETE');
    if (!ok) return;
    const wasInside = p.chats.some((c) => c.id === S.chatId);
    try { await api('delete_project', { project_id: p.id }); } catch (e) { toast(e.message); return; }
    toast('Project deleted.');
    if (wasInside) await reopenAfterDelete(); else await refreshMenu();
  }

  async function newChat() {
    try { renderChat(await api('new_chat')); } catch (e) { toast(e.message); return; }
    setState('IDLE');
    await refreshMenu();
    closeDrawer();
    els.input.focus();
  }

  async function newProject() {
    const name = await promptDialog('NEW PROJECT', 'Project name (optional)', '', 'CREATE');
    if (name === null) return;
    try { renderChat(await api('new_project', { name: name.trim() })); } catch (e) { toast(e.message); return; }
    setState('IDLE');
    await refreshMenu();
    closeDrawer();
    els.input.focus();
  }

  // ------------------------------------------------------------------ side panels

  function setMeter(id, valId, value, extra) {
    const bar = $('#' + id), val = $('#' + valId);
    if (value === null || value === undefined) { bar.style.width = '0'; val.textContent = '—'; return; }
    bar.style.width = value + '%';
    bar.classList.toggle('hot', value >= 85);
    val.textContent = value + '%';
    if (extra !== undefined) val.title = extra;
  }

  async function pollSystem() {
    if (!document.hidden) {
      try {
        const s = await api('system');
        setMeter('mCpu', 'vCpu', s.cpu);
        setMeter('mRam', 'vRam', s.ram);
        setMeter('mDisk', 'vDisk', s.disk);
        setMeter('mBat', 'vBat', s.battery, s.charging ? 'Charging' : 'On battery');
      } catch (_) { /* engine briefly busy; try again next tick */ }
    }
    setTimeout(pollSystem, 3000);
  }

  const hhmm = (ts) => new Date(ts * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

  async function refreshActivity() {
    let items;
    try { items = (await api('activity')).items; } catch (_) { return; }
    $('#actCount').textContent = String(items.length);
    const list = $('#activity');
    if (!items.length) { list.replaceChildren(el('li', { class: 'none', text: 'No activity yet' })); return; }
    list.replaceChildren(...items.slice(0, 4).map((i) => el('li', { 'data-kind': i.kind }, el('span', { text: i.detail, title: i.detail }), el('time', { text: hhmm(i.ts) }))));
  }

  function tickClock() {
    const now = new Date();
    $('#clockTime').textContent = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' }).formatToParts(now).map((x) => [x.type, x.value]));
    $('#clockDate').textContent = `${p.weekday} · ${p.day} ${p.month} ${p.year}`.toUpperCase();
  }

  // ------------------------------------------------------------------ wiring

  els.form.addEventListener('submit', (e) => { e.preventDefault(); send(els.input.value); });
  els.menuBtn.addEventListener('click', toggleDrawer);
  $('#drawerClose').addEventListener('click', closeDrawer);
  els.scrim.addEventListener('click', closeDrawer);
  $('#newChatBtn').addEventListener('click', newChat);
  $('#newProjectBtn').addEventListener('click', newProject);
  $('#settingsBtn').addEventListener('click', settingsDialog);
  els.mic.addEventListener('click', () => toast('Voice input is coming in the next update. Type for now.'));
  els.stop.addEventListener('click', () => { setState('IDLE'); });

  let searchTimer = null;
  els.search.addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => { S.query = els.search.value; refreshMenu(); }, 180);
  });

  $('#quick').addEventListener('click', (e) => {
    const b = e.target.closest('button[data-fill]');
    if (!b) return;
    els.input.value = b.dataset.fill;
    els.input.focus();
    els.input.setSelectionRange(els.input.value.length, els.input.value.length);
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (!modal.root.hidden) { modal.onEsc && modal.onEsc(); return; }
      closeDrawer();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'l') {
      e.preventDefault(); els.input.focus(); els.input.select();
    } else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'm') {
      e.preventDefault(); toggleDrawer();
    }
  });

  document.addEventListener('visibilitychange', () => {
    document.documentElement.classList.toggle('paused', document.hidden);
    if (!document.hidden) wave.restart();
  });

  // Public hooks: the voice engine (next phase) drives these.
  window.Luna = {
    setState: (name, line) => { if (['IDLE', 'LISTENING', 'THINKING', 'SPEAKING', 'ERROR'].includes(name)) setState(name, line); },
    setLevel: (v) => wave.setLevel(v),
    get state() { return S.state; },
  };

  async function init() {
    tickClock();
    setInterval(tickClock, 10000);
    setState('IDLE');
    try {
      applyStatus(await api('status'));
      renderChat(await api('start'));
    } catch (e) {
      setState('ERROR', firstSentence(e.message));
      addMsg('err', e.message, 'ERROR');
    }
    refreshMenu();
    refreshActivity();
    pollSystem();
    setInterval(refreshActivity, 6000);
    els.input.focus();
  }
  init();
})();
