"""Local, persistent storage for chats and projects (a single JSON file on this PC).

A *project* is a named group of chats. Saying "new project" creates a project and opens
a fresh chat inside it. Nothing here ever leaves the machine.
"""
from __future__ import annotations

import json
import os
import tempfile
import threading
import time
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from app.config.settings import PROJECT_ROOT

DEFAULT_PATH = PROJECT_ROOT / "data" / "chats.json"
TITLE_MAX = 40
DEFAULT_CHAT_TITLE = "New chat"


def _now() -> float:
    return time.time()


def _new_id() -> str:
    return uuid.uuid4().hex[:12]


@dataclass
class Message:
    role: str  # "user" | "assistant"
    text: str
    ts: float = field(default_factory=_now)


@dataclass
class Chat:
    id: str
    title: str = DEFAULT_CHAT_TITLE
    project_id: Optional[str] = None
    created: float = field(default_factory=_now)
    updated: float = field(default_factory=_now)
    messages: List[Message] = field(default_factory=list)
    auto_title: bool = True  # becomes False once the user renames it


@dataclass
class Project:
    id: str
    name: str
    created: float = field(default_factory=_now)


class StoreError(Exception):
    """Safe-to-display error (unknown id, empty name, ...)."""


class ChatStore:
    def __init__(self, path: Optional[Path] = None) -> None:
        self._path = Path(path) if path is not None else DEFAULT_PATH
        self._lock = threading.RLock()
        self._chats: Dict[str, Chat] = {}
        self._projects: Dict[str, Project] = {}
        self._load()

    # ------------------------------------------------------------- persistence

    def _load(self) -> None:
        if not self._path.is_file():
            return
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
            for p in raw.get("projects", []):
                project = Project(id=str(p["id"]), name=str(p["name"]), created=float(p.get("created", 0)))
                self._projects[project.id] = project
            for c in raw.get("chats", []):
                messages = [
                    Message(role=str(m["role"]), text=str(m["text"]), ts=float(m.get("ts", 0)))
                    for m in c.get("messages", [])
                    if m.get("role") in ("user", "assistant")
                ]
                chat = Chat(
                    id=str(c["id"]),
                    title=str(c.get("title") or DEFAULT_CHAT_TITLE),
                    project_id=c.get("project_id") if c.get("project_id") in self._projects else None,
                    created=float(c.get("created", 0)),
                    updated=float(c.get("updated", 0)),
                    messages=messages,
                    auto_title=bool(c.get("auto_title", True)),
                )
                self._chats[chat.id] = chat
        except (OSError, ValueError, KeyError, TypeError):
            # A damaged file must not stop Luna from starting. Keep it for inspection.
            try:
                self._path.replace(self._path.with_suffix(".damaged.json"))
            except OSError:
                pass
            self._chats.clear()
            self._projects.clear()

    def _save(self) -> None:
        data = {
            "projects": [asdict(p) for p in self._projects.values()],
            "chats": [asdict(c) for c in self._chats.values()],
        }
        self._path.parent.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=self._path.parent, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False, indent=1)
            os.replace(tmp, self._path)  # atomic: never leaves a half-written file
        except OSError:
            try:
                os.unlink(tmp)
            except OSError:
                pass
            raise

    # ----------------------------------------------------------------- queries

    def get_chat(self, chat_id: str) -> Chat:
        with self._lock:
            chat = self._chats.get(chat_id)
            if chat is None:
                raise StoreError("That chat no longer exists.")
            return chat

    def get_project(self, project_id: str) -> Project:
        with self._lock:
            project = self._projects.get(project_id)
            if project is None:
                raise StoreError("That project no longer exists.")
            return project

    def overview(self, query: str = "", keep_id: Optional[str] = None) -> Dict[str, Any]:
        """Everything the menu needs: projects (with their chats) and ungrouped chats.
        Blank chats are left out (they would only clutter the list) except `keep_id`,
        the chat currently open on screen."""
        needle = query.strip().lower()
        with self._lock:
            def chat_row(c: Chat) -> Dict[str, Any]:
                return {
                    "id": c.id,
                    "title": c.title,
                    "project_id": c.project_id,
                    "updated": c.updated,
                    "count": len(c.messages),
                }

            def matches(c: Chat) -> bool:
                if not c.messages and c.id != keep_id:
                    return False
                if not needle:
                    return True
                return needle in c.title.lower() or any(needle in m.text.lower() for m in c.messages)

            by_recent = sorted(self._chats.values(), key=lambda c: c.updated, reverse=True)
            projects = []
            for project in sorted(self._projects.values(), key=lambda p: p.created, reverse=True):
                rows = [chat_row(c) for c in by_recent if c.project_id == project.id and matches(c)]
                if needle and not rows and needle not in project.name.lower():
                    continue
                projects.append({"id": project.id, "name": project.name, "chats": rows})
            loose = [chat_row(c) for c in by_recent if c.project_id is None and matches(c)]
            return {"projects": projects, "chats": loose}

    def messages(self, chat_id: str) -> List[Dict[str, Any]]:
        chat = self.get_chat(chat_id)
        with self._lock:
            return [{"role": m.role, "text": m.text, "ts": m.ts} for m in chat.messages]

    def latest_chat_id(self) -> Optional[str]:
        with self._lock:
            if not self._chats:
                return None
            return max(self._chats.values(), key=lambda c: c.updated).id

    # --------------------------------------------------------------- mutations

    def new_chat(self, project_id: Optional[str] = None) -> Chat:
        """Create a chat. An existing *empty* chat in the same place is reused so that
        saying "new chat" repeatedly does not pile up blank entries."""
        with self._lock:
            if project_id is not None:
                self.get_project(project_id)
            for chat in sorted(self._chats.values(), key=lambda c: c.updated, reverse=True):
                if chat.project_id == project_id and not chat.messages:
                    chat.updated = _now()
                    self._save()
                    return chat
            chat = Chat(id=_new_id(), project_id=project_id)
            self._chats[chat.id] = chat
            self._save()
            return chat

    def new_project(self, name: Optional[str] = None) -> Chat:
        """Create a project and a fresh chat inside it; returns that chat."""
        with self._lock:
            clean = self._clean_name(name) if name else self._default_project_name()
            project = Project(id=_new_id(), name=clean)
            self._projects[project.id] = project
            chat = Chat(id=_new_id(), project_id=project.id)
            self._chats[chat.id] = chat
            self._save()
            return chat

    def add_message(self, chat_id: str, role: str, text: str) -> Message:
        if role not in ("user", "assistant"):
            raise StoreError("Invalid message role.")
        with self._lock:
            chat = self.get_chat(chat_id)
            message = Message(role=role, text=text)
            chat.messages.append(message)
            chat.updated = message.ts
            if role == "user" and chat.auto_title and chat.title == DEFAULT_CHAT_TITLE:
                chat.title = self._title_from(text)
            self._save()
            return message

    def remove_last_message(self, chat_id: str, role: str) -> None:
        """Roll back a message when the request it belonged to failed."""
        with self._lock:
            chat = self.get_chat(chat_id)
            if chat.messages and chat.messages[-1].role == role:
                chat.messages.pop()
                if not chat.messages and chat.auto_title:
                    chat.title = DEFAULT_CHAT_TITLE
                self._save()

    def rename_chat(self, chat_id: str, title: str) -> Chat:
        with self._lock:
            chat = self.get_chat(chat_id)
            chat.title = self._clean_name(title)
            chat.auto_title = False
            self._save()
            return chat

    def rename_project(self, project_id: str, name: str) -> Project:
        with self._lock:
            project = self.get_project(project_id)
            project.name = self._clean_name(name)
            self._save()
            return project

    def delete_chat(self, chat_id: str) -> None:
        with self._lock:
            self.get_chat(chat_id)
            del self._chats[chat_id]
            self._save()

    def delete_project(self, project_id: str) -> int:
        """Delete a project and every chat in it. Returns how many chats were removed."""
        with self._lock:
            self.get_project(project_id)
            doomed = [c.id for c in self._chats.values() if c.project_id == project_id]
            for chat_id in doomed:
                del self._chats[chat_id]
            del self._projects[project_id]
            self._save()
            return len(doomed)

    # ----------------------------------------------------------------- helpers

    @staticmethod
    def _clean_name(name: str) -> str:
        clean = " ".join(str(name).split())[:60]
        if not clean:
            raise StoreError("The name can't be empty.")
        return clean

    @staticmethod
    def _title_from(text: str) -> str:
        flat = " ".join(text.split())
        if len(flat) <= TITLE_MAX:
            return flat or DEFAULT_CHAT_TITLE
        return flat[: TITLE_MAX - 1].rstrip() + "…"

    def _default_project_name(self) -> str:
        names = {p.name for p in self._projects.values()}
        n = 1
        while f"Project {n}" in names:
            n += 1
        return f"Project {n}"
