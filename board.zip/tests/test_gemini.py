import unittest

import requests

from app.ai import (
    AINetworkError,
    AIRateLimitError,
    AIResponseError,
    AITimeoutError,
    ChatMessage,
    GeminiService,
    InvalidAPIKeyError,
    MissingAPIKeyError,
)
from app.config import Settings

FAKE_KEY = "AI" + "za" + "x" * 35


class FakeResponse:
    def __init__(self, status=200, body=None, bad_json=False):
        self.status_code = status
        self._body = body
        self._bad_json = bad_json

    def json(self):
        if self._bad_json:
            raise ValueError("not json")
        return self._body


class FakeSession:
    def __init__(self, response=None, error=None):
        self.response = response
        self.error = error
        self.calls = []

    def _do(self, method, url, **kwargs):
        self.calls.append((method, url, kwargs))
        if self.error:
            raise self.error
        return self.response

    def post(self, url, **kwargs):
        return self._do("post", url, **kwargs)

    def get(self, url, **kwargs):
        return self._do("get", url, **kwargs)


def ok_body(text="Hello!"):
    return {"candidates": [{"content": {"parts": [{"text": text}]}, "finishReason": "STOP"}]}


def service(session, key=FAKE_KEY):
    return GeminiService(Settings(gemini_api_key=key, gemini_model="test-model"), session=session)


MESSAGES = [ChatMessage("user", "Hi")]


class GeminiGenerateTests(unittest.TestCase):
    def test_success_returns_text(self):
        session = FakeSession(FakeResponse(200, ok_body("Hi there")))
        reply = service(session).generate(MESSAGES)
        self.assertEqual(reply.text, "Hi there")
        self.assertEqual(reply.provider, "gemini")
        self.assertEqual(reply.model, "test-model")

    def test_key_goes_in_header_never_in_url(self):
        session = FakeSession(FakeResponse(200, ok_body()))
        service(session).generate(MESSAGES)
        method, url, kwargs = session.calls[0]
        self.assertNotIn(FAKE_KEY, url)
        self.assertEqual(kwargs["headers"]["x-goog-api-key"], FAKE_KEY)
        self.assertTrue(url.endswith("/models/test-model:generateContent"))

    def test_request_payload_maps_roles_and_system_instruction(self):
        session = FakeSession(FakeResponse(200, ok_body()))
        history = [ChatMessage("user", "a"), ChatMessage("assistant", "b"), ChatMessage("user", "c")]
        service(session).generate(history, system_instruction="You are Luna.")
        payload = session.calls[0][2]["json"]
        self.assertEqual([c["role"] for c in payload["contents"]], ["user", "model", "user"])
        self.assertEqual(payload["systemInstruction"]["parts"][0]["text"], "You are Luna.")

    def test_thought_parts_are_skipped(self):
        body = {"candidates": [{"content": {"parts": [
            {"text": "secret reasoning", "thought": True}, {"text": "Answer"}]}}]}
        reply = service(FakeSession(FakeResponse(200, body))).generate(MESSAGES)
        self.assertEqual(reply.text, "Answer")

    def test_missing_key_raises_without_any_network_call(self):
        session = FakeSession(error=AssertionError("network must not be used"))
        with self.assertRaises(MissingAPIKeyError):
            service(session, key=None).generate(MESSAGES)
        self.assertEqual(session.calls, [])

    def test_empty_conversation_is_rejected(self):
        with self.assertRaises(AIResponseError):
            service(FakeSession(FakeResponse(200, ok_body()))).generate([])


class GeminiErrorTests(unittest.TestCase):
    def assert_raises_for(self, response, exc):
        with self.assertRaises(exc):
            service(FakeSession(response)).generate(MESSAGES)

    def test_invalid_key_400(self):
        body = {"error": {"message": "API key not valid. Please pass a valid API key."}}
        self.assert_raises_for(FakeResponse(400, body), InvalidAPIKeyError)

    def test_forbidden_403(self):
        self.assert_raises_for(FakeResponse(403, {"error": {"message": "denied"}}), InvalidAPIKeyError)

    def test_unauthorized_401(self):
        self.assert_raises_for(FakeResponse(401, {}), InvalidAPIKeyError)

    def test_rate_limit_429(self):
        self.assert_raises_for(FakeResponse(429, {}), AIRateLimitError)

    def test_server_error_500(self):
        self.assert_raises_for(FakeResponse(500, {}), AIResponseError)

    def test_model_not_found_names_the_model_and_env_var(self):
        with self.assertRaises(AIResponseError) as ctx:
            service(FakeSession(FakeResponse(404, {}))).generate(MESSAGES)
        self.assertIn("test-model", str(ctx.exception))
        self.assertIn("GEMINI_MODEL", str(ctx.exception))

    def test_other_bad_request_includes_detail(self):
        body = {"error": {"message": "Unsupported something"}}
        with self.assertRaises(AIResponseError) as ctx:
            service(FakeSession(FakeResponse(400, body))).generate(MESSAGES)
        self.assertIn("Unsupported something", str(ctx.exception))

    def test_connection_error(self):
        session = FakeSession(error=requests.exceptions.ConnectionError("boom"))
        with self.assertRaises(AINetworkError):
            service(session).generate(MESSAGES)

    def test_timeout(self):
        session = FakeSession(error=requests.exceptions.Timeout("slow"))
        with self.assertRaises(AITimeoutError):
            service(session).generate(MESSAGES)

    def test_generic_request_exception_is_network_error(self):
        session = FakeSession(error=requests.exceptions.RequestException("odd"))
        with self.assertRaises(AINetworkError):
            service(session).generate(MESSAGES)

    def test_blocked_prompt(self):
        body = {"promptFeedback": {"blockReason": "SAFETY"}}
        with self.assertRaises(AIResponseError) as ctx:
            service(FakeSession(FakeResponse(200, body))).generate(MESSAGES)
        self.assertIn("SAFETY", str(ctx.exception))

    def test_no_candidates(self):
        self.assert_raises_for(FakeResponse(200, {"candidates": []}), AIResponseError)

    def test_empty_text(self):
        body = {"candidates": [{"content": {"parts": []}, "finishReason": "MAX_TOKENS"}]}
        self.assert_raises_for(FakeResponse(200, body), AIResponseError)

    def test_non_json_body(self):
        self.assert_raises_for(FakeResponse(200, bad_json=True), AIResponseError)

    def test_non_object_json(self):
        self.assert_raises_for(FakeResponse(200, ["unexpected"]), AIResponseError)

    def test_key_echoed_by_server_is_redacted_from_errors(self):
        body = {"error": {"message": f"bad request for key {FAKE_KEY}"}}
        with self.assertRaises(AIResponseError) as ctx:
            service(FakeSession(FakeResponse(400, body))).generate(MESSAGES)
        self.assertNotIn(FAKE_KEY, str(ctx.exception))

    def test_key_echoed_in_reply_text_is_redacted(self):
        reply = service(FakeSession(FakeResponse(200, ok_body(f"your key is {FAKE_KEY}")))).generate(MESSAGES)
        self.assertNotIn(FAKE_KEY, reply.text)


class GeminiConnectionCheckTests(unittest.TestCase):
    def test_check_connection_ok_uses_get_on_model(self):
        session = FakeSession(FakeResponse(200, {"name": "models/test-model"}))
        service(session).check_connection()
        method, url, kwargs = session.calls[0]
        self.assertEqual(method, "get")
        self.assertTrue(url.endswith("/models/test-model"))
        self.assertNotIn(FAKE_KEY, url)

    def test_check_connection_bad_key(self):
        session = FakeSession(FakeResponse(403, {}))
        with self.assertRaises(InvalidAPIKeyError):
            service(session).check_connection()

    def test_check_connection_without_key(self):
        with self.assertRaises(MissingAPIKeyError):
            service(FakeSession(), key=None).check_connection()


if __name__ == "__main__":
    unittest.main()
