import tempfile
import unittest
from pathlib import Path

from app.agent import Assistant
from app.agent.assistant import CONTEXT_MESSAGES, SYSTEM_INSTRUCTION
from app.ai import AINetworkError, AIProvider, AIResponse
from app.chat import ChatStore
from app.config import Settings

KEY = "AI" + "za" + "x" * 35


class ScriptedProvider(AIProvider):
    def __init__(self, replies=None, error=None):
        self.replies = list(replies or ["ok"])
        self.error = error
        self.calls = []

    def generate(self, messages, system_instruction=None):
        self.calls.append((list(messages), system_instruction))
        if self.error:
            raise self.error
        return AIResponse(text=self.replies.pop(0) if self.replies else "ok", provider="test", model="m")

    def check_connection(self):
        pass


class AssistantTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.store = ChatStore(Path(self._tmp.name) / "chats.json")
        self.env = Path(self._tmp.name) / ".env"

    def make(self, provider, key=KEY):
        return Assistant(self.store, provider, Settings(gemini_api_key=key, env_file=self.env))

    def test_message_goes_to_gemini_and_is_stored(self):
        provider = ScriptedProvider(["Paris."])
        assistant = self.make(provider)
        chat = self.store.new_chat()
        reply = assistant.handle(chat.id, "Capital of France?")
        self.assertTrue(reply.ok)
        self.assertEqual(reply.text, "Paris.")
        self.assertEqual([m["role"] for m in self.store.messages(chat.id)], ["user", "assistant"])

    def test_follow_up_sends_earlier_turns_for_context(self):
        provider = ScriptedProvider(["Real Madrid won.", "Last night."])
        assistant = self.make(provider)
        chat = self.store.new_chat()
        assistant.handle(chat.id, "Who won the match?")
        assistant.handle(chat.id, "When was it?")
        sent, system = provider.calls[1]
        self.assertEqual([m.text for m in sent], ["Who won the match?", "Real Madrid won.", "When was it?"])
        self.assertEqual(system, SYSTEM_INSTRUCTION)

    def test_context_is_limited(self):
        provider = ScriptedProvider()
        assistant = self.make(provider)
        chat = self.store.new_chat()
        for i in range(CONTEXT_MESSAGES):
            assistant.handle(chat.id, f"message {i}")
        sent, _ = provider.calls[-1]
        self.assertLessEqual(len(sent), CONTEXT_MESSAGES)

    def test_new_chat_command_does_not_call_gemini(self):
        provider = ScriptedProvider()
        assistant = self.make(provider)
        old = self.store.new_chat()
        self.store.add_message(old.id, "user", "hi")
        reply = assistant.handle(old.id, "new chat")
        self.assertEqual(reply.action, "new_chat")
        self.assertNotEqual(reply.chat_id, old.id)
        self.assertEqual(provider.calls, [])

    def test_new_project_command_creates_project_chat(self):
        provider = ScriptedProvider()
        assistant = self.make(provider)
        reply = assistant.handle(None, "new project called Robots")
        self.assertEqual(reply.action, "new_project")
        chat = self.store.get_chat(reply.chat_id)
        self.assertEqual(self.store.get_project(chat.project_id).name, "Robots")
        self.assertEqual(provider.calls, [])

    def test_commands_work_even_without_api_key(self):
        assistant = self.make(ScriptedProvider(), key=None)
        self.assertEqual(assistant.handle(None, "new project").action, "new_project")

    def test_missing_key_shows_setup_and_keeps_text_for_retry(self):
        provider = ScriptedProvider()
        assistant = self.make(provider, key=None)
        chat = self.store.new_chat()
        reply = assistant.handle(chat.id, "hello")
        self.assertFalse(reply.ok)
        self.assertEqual(reply.error_kind, "missing_key")
        self.assertIn("GEMINI_API_KEY", reply.text)
        self.assertEqual(reply.restore_text, "hello")
        self.assertEqual(self.store.messages(chat.id), [])
        self.assertEqual(provider.calls, [])

    def test_failure_rolls_back_user_message_and_never_fakes_a_reply(self):
        assistant = self.make(ScriptedProvider(error=AINetworkError("Luna can't reach Gemini.")))
        chat = self.store.new_chat()
        reply = assistant.handle(chat.id, "hello")
        self.assertFalse(reply.ok)
        self.assertEqual(reply.restore_text, "hello")
        self.assertEqual(self.store.messages(chat.id), [])
        self.assertEqual(self.store.get_chat(chat.id).title, "New chat")

    def test_empty_text_is_rejected(self):
        reply = self.make(ScriptedProvider()).handle(None, "   ")
        self.assertFalse(reply.ok)

    def test_activity_log_records_events(self):
        assistant = self.make(ScriptedProvider())
        chat = self.store.new_chat()
        assistant.handle(chat.id, "hi")
        assistant.handle(chat.id, "new project")
        kinds = [a["kind"] for a in assistant.activity()]
        self.assertIn("gemini", kinds)
        self.assertIn("project", kinds)

    def test_system_instruction_does_not_claim_abilities_it_lacks(self):
        self.assertIn("ONLY hold a conversation", SYSTEM_INSTRUCTION)


if __name__ == "__main__":
    unittest.main()
