import unittest

from app.agent.commands import Command, parse_command


class CommandParserTests(unittest.TestCase):
    def test_new_chat_phrases(self):
        for text in ["new chat", "New chat.", "hey luna, new chat", "Luna start a new chat please",
                     "can you open a new chat", "start a fresh conversation", "new conversation"]:
            with self.subTest(text=text):
                self.assertEqual(parse_command(text), Command("new_chat"))

    def test_new_project_phrases(self):
        for text in ["new project", "Hey Luna, new project", "start a new project", "create another project",
                     "open a new project please"]:
            with self.subTest(text=text):
                self.assertEqual(parse_command(text), Command("new_project"))

    def test_new_project_with_name(self):
        cases = {
            "new project called Website": "Website",
            "start a project named My App please": "My App",
            "new project Website": "Website",
            "new project: Luna UI": "Luna UI",
            "create a new project called Fitness Plan!": "Fitness Plan",
        }
        for text, name in cases.items():
            with self.subTest(text=text):
                self.assertEqual(parse_command(text), Command("new_project", name))

    def test_normal_requests_are_not_commands(self):
        for text in ["make a project plan for my app", "write a story about a new project manager",
                     "what is a new chat app", "project status", "tell me about the project",
                     "create a project plan", "new chats are cool", "how do I start a new project at work?",
                     "", "   ", "x" * 500]:
            with self.subTest(text=text[:40]):
                self.assertIsNone(parse_command(text))


if __name__ == "__main__":
    unittest.main()
