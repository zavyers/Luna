import json
import tempfile
import unittest
import urllib.error
import urllib.request
from pathlib import Path

from app.ai import AIProvider, AIResponse
from app.chat import ChatStore
from app.config import Settings
from app.ui.server import LunaServer, build_app

KEY = "AI" + "za" + "x" * 35


class EchoProvider(AIProvider):
    def generate(self, messages, system_instruction=None):
        return AIResponse(text="echo: " + messages[-1].text)

    def check_connection(self):
        pass


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._tmp = tempfile.TemporaryDirectory()
        tmp = Path(cls._tmp.name)
        settings = Settings(gemini_api_key=KEY, env_file=tmp / ".env")
        cls.app = build_app(settings, ChatStore(tmp / "chats.json"), EchoProvider())
        cls.server = LunaServer(cls.app)
        cls.server.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.stop()
        cls._tmp.cleanup()

    def post(self, method, args=None, token=True, host=None, origin=None, raw=None):
        headers = {"Content-Type": "application/json"}
        if token:
            headers["X-Luna-Token"] = self.app.token
        if host:
            headers["Host"] = host
        if origin:
            headers["Origin"] = origin
        data = raw if raw is not None else json.dumps(args or {}).encode()
        req = urllib.request.Request(self.server.url + "api/" + method, data=data, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=5) as r:
                return r.status, json.loads(r.read())
        except urllib.error.HTTPError as e:
            return e.code, json.loads(e.read() or b"{}")

    def get(self, path):
        try:
            with urllib.request.urlopen(self.server.url + path, timeout=5) as r:
                return r.status, r.read().decode(), dict(r.headers)
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode(), dict(e.headers)

    # -- pages -----------------------------------------------------------------

    def test_index_is_served_with_token_injected_once(self):
        status, body, headers = self.get("")
        self.assertEqual(status, 200)
        self.assertIn(self.app.token, body)
        self.assertNotIn("__LUNA_TOKEN__", body)
        self.assertIn("default-src 'self'", headers["Content-Security-Policy"])

    def test_static_assets_served(self):
        for name in ("style.css", "app.js"):
            self.assertEqual(self.get(name)[0], 200)

    def test_path_traversal_is_blocked(self):
        status, body, _ = self.get("..%2f..%2fmain.py")
        self.assertEqual(status, 404)
        self.assertNotIn("argparse", body)

    def test_the_api_key_never_appears_in_any_served_page(self):
        for name in ("", "style.css", "app.js"):
            self.assertNotIn(KEY, self.get(name)[1])

    # -- security --------------------------------------------------------------

    def test_api_requires_token(self):
        status, _ = self.post("status", token=False)
        self.assertEqual(status, 403)

    def test_wrong_host_is_refused(self):
        status, _ = self.post("status", host="evil.example.com")
        self.assertEqual(status, 403)

    def test_foreign_origin_is_refused(self):
        status, _ = self.post("status", origin="http://evil.example.com")
        self.assertEqual(status, 403)

    def test_bad_json_and_non_object_are_rejected(self):
        self.assertEqual(self.post("status", raw=b"{oops")[0], 400)
        self.assertEqual(self.post("status", raw=b"[1,2]")[0], 400)

    def test_unknown_method_and_private_attributes_are_not_callable(self):
        self.assertEqual(self.post("nonsense")[0], 404)
        self.assertEqual(self.post("_chat_payload")[0], 404)
        self.assertEqual(self.post("token")[0], 404)

    def test_argument_validation(self):
        self.assertEqual(self.post("open_chat", {"chat_id": 5})[0], 400)
        self.assertEqual(self.post("open_chat", {})[0], 400)
        self.assertEqual(self.post("send", {"text": "x" * 9000})[0], 400)
        self.assertEqual(self.post("open_chat", {"chat_id": "missing"})[0], 404)

    # -- behaviour -------------------------------------------------------------

    def test_status_never_contains_the_key(self):
        status, body = self.post("status")
        self.assertEqual(status, 200)
        self.assertEqual(body["gemini"], "configured")
        self.assertNotIn(KEY, json.dumps(body))

    def test_chat_flow_and_commands(self):
        _, chat = self.post("start")
        status, reply = self.post("send", {"chat_id": chat["id"], "text": "hello there"})
        self.assertEqual(reply["text"], "echo: hello there")
        self.assertEqual([m["role"] for m in reply["chat"]["messages"]], ["user", "assistant"])

        _, cmd = self.post("send", {"chat_id": chat["id"], "text": "new project called Demo"})
        self.assertEqual(cmd["action"], "new_project")
        self.assertEqual(cmd["chat"]["project"]["name"], "Demo")
        self.assertNotEqual(cmd["chat"]["id"], chat["id"])

        _, view = self.post("overview")
        self.assertIn("Demo", [p["name"] for p in view["projects"]])
        self.assertIn("hello there", [c["title"] for c in view["chats"]])

    def test_rename_and_delete(self):
        _, made = self.post("new_project", {"name": "Temp"})
        pid = made["project"]["id"]
        self.assertEqual(self.post("rename_project", {"project_id": pid, "name": "Renamed"})[0], 200)
        self.assertEqual(self.post("rename_chat", {"chat_id": made["id"], "title": "Chat X"})[0], 200)
        _, view = self.post("overview")
        self.assertIn("Renamed", [p["name"] for p in view["projects"]])
        status, result = self.post("delete_project", {"project_id": pid})
        self.assertEqual(result["removed_chats"], 1)
        self.assertEqual(self.post("open_chat", {"chat_id": made["id"]})[0], 404)

    def test_system_endpoint_shape(self):
        _, info = self.post("system")
        self.assertEqual(set(info), {"cpu", "ram", "disk", "battery", "charging"})


class MissingKeyServerTests(unittest.TestCase):
    def test_missing_key_gives_setup_message_not_a_crash(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            settings = Settings(gemini_api_key=None, env_file=tmp / ".env")
            app = build_app(settings, ChatStore(tmp / "c.json"), EchoProvider())
            server = LunaServer(app)
            server.start()
            self.addCleanup(server.stop)

            def post(method, args):
                req = urllib.request.Request(
                    server.url + "api/" + method, data=json.dumps(args).encode(),
                    headers={"X-Luna-Token": app.token, "Content-Type": "application/json"}, method="POST")
                with urllib.request.urlopen(req, timeout=5) as r:
                    return json.loads(r.read())

            status = post("status", {})
            self.assertEqual(status["gemini"], "missing_key")
            self.assertIn("GEMINI_API_KEY", status["setup_message"])
            result = post("send", {"text": "hello"})
            self.assertFalse(result["ok"])
            self.assertEqual(result["error_kind"], "missing_key")
            self.assertEqual(post("test_connection", {})["gemini"], "missing_key")


if __name__ == "__main__":
    unittest.main()
