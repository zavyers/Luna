import json
import tempfile
import unittest
from pathlib import Path

from app.chat import ChatStore
from app.chat.store import StoreError


class ChatStoreTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.path = Path(self._tmp.name) / "chats.json"
        self.store = ChatStore(self.path)

    def test_new_chat_reuses_existing_empty_chat(self):
        a = self.store.new_chat()
        b = self.store.new_chat()
        self.assertEqual(a.id, b.id)

    def test_new_chat_after_message_creates_another(self):
        a = self.store.new_chat()
        self.store.add_message(a.id, "user", "hello")
        self.assertNotEqual(a.id, self.store.new_chat().id)

    def test_first_user_message_becomes_title(self):
        chat = self.store.new_chat()
        self.store.add_message(chat.id, "user", "What is the capital of France?")
        self.assertEqual(self.store.get_chat(chat.id).title, "What is the capital of France?")

    def test_long_title_is_shortened(self):
        chat = self.store.new_chat()
        self.store.add_message(chat.id, "user", "word " * 40)
        self.assertLessEqual(len(self.store.get_chat(chat.id).title), 40)

    def test_renamed_chat_keeps_its_name(self):
        chat = self.store.new_chat()
        self.store.rename_chat(chat.id, "My name")
        self.store.add_message(chat.id, "user", "hello")
        self.assertEqual(self.store.get_chat(chat.id).title, "My name")

    def test_new_project_creates_project_and_fresh_chat(self):
        chat = self.store.new_project("Website")
        self.assertEqual(self.store.get_project(chat.project_id).name, "Website")
        self.assertEqual(chat.messages, [])

    def test_default_project_names_are_numbered(self):
        self.store.new_project()
        second = self.store.new_project()
        self.assertEqual(self.store.get_project(second.project_id).name, "Project 2")

    def test_new_chat_inside_project(self):
        project_chat = self.store.new_project("P")
        self.store.add_message(project_chat.id, "user", "hi")
        again = self.store.new_chat(project_chat.project_id)
        self.assertEqual(again.project_id, project_chat.project_id)
        self.assertNotEqual(again.id, project_chat.id)

    def test_unknown_project_is_rejected(self):
        with self.assertRaises(StoreError):
            self.store.new_chat("nope")

    def test_overview_groups_by_project_and_lists_all_chats(self):
        pc = self.store.new_project("Alpha")
        self.store.add_message(pc.id, "user", "inside project")
        loose = self.store.new_chat()
        self.store.add_message(loose.id, "user", "loose chat")
        view = self.store.overview()
        self.assertEqual([p["name"] for p in view["projects"]], ["Alpha"])
        self.assertEqual(view["projects"][0]["chats"][0]["title"], "inside project")
        self.assertEqual([c["title"] for c in view["chats"]], ["loose chat"])

    def test_overview_hides_blank_chats_except_the_open_one(self):
        blank = self.store.new_chat()
        self.assertEqual(self.store.overview()["chats"], [])
        shown = self.store.overview(keep_id=blank.id)["chats"]
        self.assertEqual([c["id"] for c in shown], [blank.id])

    def test_overview_search_matches_titles_and_message_text(self):
        a = self.store.new_chat()
        self.store.add_message(a.id, "user", "apples")
        self.store.add_message(a.id, "assistant", "Bananas are yellow")
        b = self.store.new_chat()
        self.store.add_message(b.id, "user", "cars")
        titles = [c["title"] for c in self.store.overview("banana")["chats"]]
        self.assertEqual(titles, ["apples"])

    def test_delete_chat_and_project(self):
        pc = self.store.new_project("Gone")
        extra = self.store.new_chat(pc.project_id)  # reuses the empty one
        self.assertEqual(extra.id, pc.id)
        self.assertEqual(self.store.delete_project(pc.project_id), 1)
        with self.assertRaises(StoreError):
            self.store.get_chat(pc.id)

    def test_persistence_roundtrip(self):
        chat = self.store.new_project("Saved")
        self.store.add_message(chat.id, "user", "remember me")
        self.store.add_message(chat.id, "assistant", "ok")
        reloaded = ChatStore(self.path)
        self.assertEqual([m["text"] for m in reloaded.messages(chat.id)], ["remember me", "ok"])
        self.assertEqual(reloaded.get_project(chat.project_id).name, "Saved")

    def test_damaged_file_does_not_crash_and_is_kept(self):
        self.path.write_text("{not json", encoding="utf-8")
        store = ChatStore(self.path)
        self.assertEqual(store.overview(), {"projects": [], "chats": []})
        self.assertTrue(self.path.with_suffix(".damaged.json").exists())

    def test_remove_last_message_restores_default_title(self):
        chat = self.store.new_chat()
        self.store.add_message(chat.id, "user", "oops")
        self.store.remove_last_message(chat.id, "user")
        self.assertEqual(self.store.get_chat(chat.id).title, "New chat")
        self.assertEqual(self.store.messages(chat.id), [])

    def test_empty_names_are_rejected(self):
        chat = self.store.new_chat()
        with self.assertRaises(StoreError):
            self.store.rename_chat(chat.id, "   ")

    def test_file_is_valid_json_after_writes(self):
        chat = self.store.new_chat()
        self.store.add_message(chat.id, "user", "x")
        data = json.loads(self.path.read_text(encoding="utf-8"))
        self.assertEqual(len(data["chats"]), 1)


if __name__ == "__main__":
    unittest.main()
