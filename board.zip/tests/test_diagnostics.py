import tempfile
import unittest
from pathlib import Path

from app.ai import AIProvider, InvalidAPIKeyError
from app.config import Settings
from app.diagnostics import format_report, run_checks

FAKE_KEY = "AI" + "za" + "x" * 35


class StubProvider(AIProvider):
    def __init__(self, error=None):
        self.error = error
        self.checked = False

    def generate(self, messages, system_instruction=None):
        raise AssertionError("not used")

    def check_connection(self):
        self.checked = True
        if self.error:
            raise self.error


class DiagnosticsTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self._tmp.cleanup)
        self.env = Path(self._tmp.name) / ".env"
        self.env.write_text("GEMINI_API_KEY=\n")

    def test_missing_key_skips_connection_and_shows_setup(self):
        provider = StubProvider()
        settings = Settings(gemini_api_key=None, env_file=self.env)
        results = run_checks(settings, provider)
        self.assertFalse(provider.checked)
        self.assertFalse(all(r.ok for r in results))
        report = format_report(results, settings)
        self.assertIn("Gemini API key", report)
        self.assertIn("Luna needs a Google Gemini API key", report)

    def test_successful_connection(self):
        settings = Settings(gemini_api_key=FAKE_KEY, env_file=self.env)
        results = run_checks(settings, StubProvider())
        self.assertTrue(all(r.ok for r in results))

    def test_failed_connection_reports_reason_without_key(self):
        settings = Settings(gemini_api_key=FAKE_KEY, env_file=self.env)
        results = run_checks(settings, StubProvider(InvalidAPIKeyError("Gemini rejected the API key.")))
        report = format_report(results, settings)
        self.assertIn("FAIL", report)
        self.assertIn("rejected", report)
        self.assertNotIn(FAKE_KEY, report)


if __name__ == "__main__":
    unittest.main()
