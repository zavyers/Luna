import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
KEY_SHAPE = re.compile(r"AIza[0-9A-Za-z_\-]{30,}")
SCANNED_SUFFIXES = {".py", ".md", ".txt", ".example", ".toml", ".cfg", ".json", ".gitignore"}


class SecretHygieneTests(unittest.TestCase):
    def test_no_google_api_key_hardcoded_anywhere(self):
        offenders = []
        for path in ROOT.rglob("*"):
            if not path.is_file() or ".git" in path.parts or "__pycache__" in path.parts:
                continue
            if path.name == ".env":  # the user's own private file is allowed to hold a key
                continue
            if path.suffix in SCANNED_SUFFIXES or path.name.startswith(".env"):
                if KEY_SHAPE.search(path.read_text(errors="ignore")):
                    offenders.append(str(path.relative_to(ROOT)))
        self.assertEqual(offenders, [])

    def test_env_example_has_empty_key(self):
        lines = (ROOT / ".env.example").read_text().splitlines()
        self.assertIn("GEMINI_API_KEY=", [line.strip() for line in lines])

    def test_gitignore_hides_env_but_keeps_example(self):
        if shutil.which("git") is None:
            self.skipTest("git not installed")
        with tempfile.TemporaryDirectory() as tmp:
            repo = Path(tmp)
            subprocess.run(["git", "init", "-q"], cwd=repo, check=True)
            shutil.copy(ROOT / ".gitignore", repo / ".gitignore")

            def ignored(name):
                result = subprocess.run(["git", "check-ignore", "-q", name], cwd=repo)
                return result.returncode == 0

            self.assertTrue(ignored(".env"))
            self.assertTrue(ignored(".env.local"))
            self.assertTrue(ignored("__pycache__/x.pyc"))
            self.assertTrue(ignored("venv/lib"))
            self.assertFalse(ignored(".env.example"))


if __name__ == "__main__":
    unittest.main()
